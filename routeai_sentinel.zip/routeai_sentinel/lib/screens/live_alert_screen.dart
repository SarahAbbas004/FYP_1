import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/app_models.dart';
import '../widgets/alert_and_accident_cards.dart';
import 'emergency_screen.dart';

class LiveAlertScreen extends StatefulWidget {
  const LiveAlertScreen({super.key});

  @override
  State<LiveAlertScreen> createState() => _LiveAlertScreenState();
}

class _LiveAlertScreenState extends State<LiveAlertScreen> {
  late List<LiveAlert> _alerts = List.of(dummyLiveAlerts);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Live Alerts'),
        actions: [
          IconButton(
            onPressed: () {
              setState(() => _alerts = List.of(dummyLiveAlerts));
            },
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: _alerts.isEmpty
          ? Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.check_circle_rounded,
                      color: AppColors.safe, size: 56),
                  const SizedBox(height: 12),
                  const Text('No active alerts',
                      style: TextStyle(
                          fontWeight: FontWeight.w700, fontSize: 15)),
                  const SizedBox(height: 4),
                  const Text('Your route ahead looks clear.',
                      style: TextStyle(color: AppColors.textSecondary)),
                ],
              ),
            )
          : ListView(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
              children: _alerts
                  .map(
                    (alert) => LiveAlertCard(
                      alert: alert,
                      onCall: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(
                              builder: (_) => const EmergencyScreen()),
                        );
                      },
                      onDismiss: () {
                        setState(() => _alerts.remove(alert));
                      },
                    ),
                  )
                  .toList(),
            ),
    );
  }
}
