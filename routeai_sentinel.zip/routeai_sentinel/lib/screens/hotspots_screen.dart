import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/app_models.dart';
import '../widgets/alert_and_accident_cards.dart';

class HotspotsScreen extends StatelessWidget {
  const HotspotsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Accident Hotspots')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            margin: const EdgeInsets.only(bottom: 16),
            decoration: BoxDecoration(
              color: AppColors.darkBlue.withOpacity(0.06),
              borderRadius: BorderRadius.circular(AppRadius.md),
            ),
            child: Row(
              children: const [
                Icon(Icons.info_outline_rounded, color: AppColors.darkBlue, size: 18),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Locations along Islamabad → Gilgit with a history of accidents, based on historical data.',
                    style: TextStyle(fontSize: 12.5, color: AppColors.textPrimary),
                  ),
                ),
              ],
            ),
          ),
          ...dummyHotspots.map(
            (h) => AccidentHotspotCard(data: h, onViewOnMap: () {}),
          ),
        ],
      ),
    );
  }
}
