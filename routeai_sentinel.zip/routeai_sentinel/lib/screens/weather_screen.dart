import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/app_models.dart';
import '../widgets/weather_card.dart';

class WeatherScreen extends StatelessWidget {
  const WeatherScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Weather Prediction')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: [
          const WeatherHeroCard(
            locationName: 'Besham, KPK',
            tempC: 24,
            condition: 'Partly Cloudy',
            roadStatus: 'Clear',
            isSafe: true,
          ),
          const SizedBox(height: 24),
          const Text('Next 24 Hours',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
          const SizedBox(height: 12),
          SizedBox(
            height: 130,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: dummyHourlyWeather.length,
              itemBuilder: (_, i) =>
                  WeatherForecastTile(point: dummyHourlyWeather[i]),
            ),
          ),
          const SizedBox(height: 24),
          const Text('Next 3 Days',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
          const SizedBox(height: 12),
          ...dummyThreeDayWeather.map((p) => Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(AppRadius.md),
                  boxShadow: AppShadows.card,
                ),
                child: Row(
                  children: [
                    Icon(p.icon, color: AppColors.darkBlue, size: 28),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(p.label,
                              style: const TextStyle(
                                  fontWeight: FontWeight.w700, fontSize: 13.5)),
                          Text(p.condition,
                              style: const TextStyle(
                                  fontSize: 12, color: AppColors.textSecondary)),
                        ],
                      ),
                    ),
                    Text('${p.tempC}°C',
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 16)),
                  ],
                ),
              )),
          const SizedBox(height: 12),
          _metricsRow(),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: AppColors.greenGradient,
              borderRadius: BorderRadius.circular(AppRadius.lg),
              boxShadow: AppShadows.soft,
            ),
            child: Row(
              children: [
                const Icon(Icons.auto_awesome_rounded, color: Colors.white),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text('AI Recommendation',
                          style: TextStyle(
                              color: Colors.white70,
                              fontSize: 11.5,
                              fontWeight: FontWeight.w700)),
                      SizedBox(height: 4),
                      Text(
                        'Rain expected after Dasu. Wait before travelling.',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 13.5,
                            fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _metricsRow() {
    final metrics = [
      ('Visibility', '8 km', Icons.visibility_rounded),
      ('Wind Speed', '14 km/h', Icons.air_rounded),
      ('Humidity', '61%', Icons.water_drop_rounded),
    ];
    return Row(
      children: metrics
          .map((m) => Expanded(
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(AppRadius.md),
                    boxShadow: AppShadows.card,
                  ),
                  child: Column(
                    children: [
                      Icon(m.$3, color: AppColors.info, size: 20),
                      const SizedBox(height: 6),
                      Text(m.$2,
                          style: const TextStyle(
                              fontWeight: FontWeight.w800, fontSize: 13.5)),
                      Text(m.$1,
                          style: const TextStyle(
                              fontSize: 10.5, color: AppColors.textSecondary)),
                    ],
                  ),
                ),
              ))
          .toList(),
    );
  }
}
