import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/app_models.dart';
import '../widgets/gradient_button.dart';

/// Google-Maps-style live route screen. Since no real map SDK/API key is
/// used (frontend-only, dummy data), the route is drawn with a
/// CustomPainter to visually resemble a map with markers, danger/safe
/// zones, and weather icons along an Islamabad → Gilgit path.
class LiveRouteScreen extends StatelessWidget {
  const LiveRouteScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          // Fake map background
          Positioned.fill(
            child: Container(
              color: const Color(0xFFE7EEF1),
              child: CustomPaint(
                painter: _MapGridPainter(),
                child: Container(),
              ),
            ),
          ),
          // Route line + markers
          Positioned.fill(
            child: CustomPaint(
              painter: _RoutePainter(hotspots: dummyHotspots),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  _RoundIconButton(
                    icon: Icons.arrow_back_rounded,
                    onTap: () => Navigator.of(context).pop(),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Container(
                      padding:
                          const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: AppColors.surface,
                        borderRadius: BorderRadius.circular(AppRadius.md),
                        boxShadow: AppShadows.card,
                      ),
                      child: Row(
                        children: const [
                          Icon(Icons.search_rounded,
                              color: AppColors.textSecondary, size: 20),
                          SizedBox(width: 10),
                          Text('Islamabad → Gilgit',
                              style: TextStyle(
                                  fontWeight: FontWeight.w600, fontSize: 13.5)),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  _RoundIconButton(icon: Icons.layers_rounded, onTap: () {}),
                ],
              ),
            ),
          ),
          // Bottom sheet
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
              decoration: const BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.vertical(
                    top: Radius.circular(AppRadius.xl)),
                boxShadow: [
                  BoxShadow(
                      color: Colors.black12, blurRadius: 24, offset: Offset(0, -6)),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 44,
                    height: 5,
                    decoration: BoxDecoration(
                      color: AppColors.greyLight,
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  const SizedBox(height: 18),
                  Row(
                    children: [
                      _routeStat(Icons.social_distance_rounded,
                          '412 km', 'Distance Left'),
                      _routeStat(
                          Icons.timelapse_rounded, '7h 45m', 'ETA'),
                      _routeStat(
                          Icons.cloud_rounded, 'Rain', 'Weather Ahead'),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: AppColors.safe.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(AppRadius.sm),
                    ),
                    child: Row(
                      children: const [
                        Icon(Icons.check_circle_rounded,
                            color: AppColors.safe, size: 18),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Road Status: Clear with minor debris near Besham',
                            style: TextStyle(
                                fontSize: 12.5,
                                fontWeight: FontWeight.w600,
                                color: AppColors.textPrimary),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  GradientButton(
                    label: 'Start Navigation',
                    icon: Icons.navigation_rounded,
                    gradient: AppColors.greenGradient,
                    onPressed: () {},
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _routeStat(IconData icon, String value, String label) {
    return Expanded(
      child: Column(
        children: [
          Icon(icon, color: AppColors.darkBlue, size: 20),
          const SizedBox(height: 6),
          Text(value,
              style: const TextStyle(
                  fontWeight: FontWeight.w800, fontSize: 14.5)),
          Text(label,
              style: const TextStyle(
                  fontSize: 10.5, color: AppColors.textSecondary)),
        ],
      ),
    );
  }
}

class _RoundIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _RoundIconButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.surface,
      shape: const CircleBorder(),
      elevation: 2,
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Icon(icon, size: 20, color: AppColors.darkBlue),
        ),
      ),
    );
  }
}

/// Draws a faint grid to fake a map background texture.
class _MapGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.6)
      ..strokeWidth = 1;
    const gap = 32.0;
    for (double x = 0; x < size.width; x += gap) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += gap) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Draws the Islamabad → Gilgit route as a curved line with markers
/// for accident hotspots, danger/safe zones, and the driver's position.
class _RoutePainter extends CustomPainter {
  final List<AccidentHotspot> hotspots;
  _RoutePainter({required this.hotspots});

  @override
  void paint(Canvas canvas, Size size) {
    final start = Offset(size.width * 0.2, size.height * 0.18);
    final end = Offset(size.width * 0.75, size.height * 0.82);

    final path = Path()..moveTo(start.dx, start.dy);
    path.cubicTo(
      size.width * 0.1,
      size.height * 0.45,
      size.width * 0.85,
      size.height * 0.4,
      end.dx,
      end.dy,
    );

    final routePaint = Paint()
      ..color = AppColors.darkBlue
      ..strokeWidth = 6
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(path, routePaint);

    final dashPaint = Paint()
      ..color = Colors.white
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    canvas.drawPath(path, dashPaint);

    // Start marker (Islamabad)
    _drawMarker(canvas, start, AppColors.darkBlue, Icons.my_location_rounded);
    // End marker (Gilgit)
    _drawMarker(canvas, end, AppColors.green, Icons.flag_rounded);

    // Approximate positions for hotspots along the cubic curve using t values
    for (final h in hotspots) {
      final pos = _pointOnCubic(
        start,
        Offset(size.width * 0.1, size.height * 0.45),
        Offset(size.width * 0.85, size.height * 0.4),
        end,
        h.progressAlongRoute,
      );
      _drawMarker(canvas, pos, h.risk.color, Icons.warning_rounded, size: 26);
    }
  }

  Offset _pointOnCubic(Offset p0, Offset p1, Offset p2, Offset p3, double t) {
    final mt = 1 - t;
    final x = mt * mt * mt * p0.dx +
        3 * mt * mt * t * p1.dx +
        3 * mt * t * t * p2.dx +
        t * t * t * p3.dx;
    final y = mt * mt * mt * p0.dy +
        3 * mt * mt * t * p1.dy +
        3 * mt * t * t * p2.dy +
        t * t * t * p3.dy;
    return Offset(x, y);
  }

  void _drawMarker(Canvas canvas, Offset center, Color color, IconData icon,
      {double size = 34}) {
    final circlePaint = Paint()..color = Colors.white;
    final borderPaint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;
    canvas.drawCircle(center, size / 2, circlePaint);
    canvas.drawCircle(center, size / 2, borderPaint);

    final textPainter = TextPainter(textDirection: TextDirection.ltr);
    textPainter.text = TextSpan(
      text: String.fromCharCode(icon.codePoint),
      style: TextStyle(
        fontSize: size * 0.5,
        fontFamily: icon.fontFamily,
        package: icon.fontPackage,
        color: color,
      ),
    );
    textPainter.layout();
    textPainter.paint(
      canvas,
      center - Offset(textPainter.width / 2, textPainter.height / 2),
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
