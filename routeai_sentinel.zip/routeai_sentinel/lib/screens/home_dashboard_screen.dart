import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/app_models.dart';
import '../widgets/weather_card.dart';
import '../widgets/nav_and_buttons.dart';
import '../widgets/alert_and_accident_cards.dart';
import 'live_route_screen.dart';
import 'hotspots_screen.dart';
import 'weather_screen.dart';
import 'emergency_screen.dart';

class HomeDashboardScreen extends StatelessWidget {
  const HomeDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Assalam-o-Alaikum,',
                        style: TextStyle(
                            fontSize: 13,
                            color: AppColors.textSecondary.withOpacity(0.9))),
                    const Text('Ahmad Raza',
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                            color: AppColors.textPrimary)),
                  ],
                ),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    shape: BoxShape.circle,
                    boxShadow: AppShadows.card,
                  ),
                  child: const Icon(Icons.notifications_none_rounded,
                      color: AppColors.darkBlue),
                ),
              ],
            ),
            const SizedBox(height: 20),
            const WeatherHeroCard(
              locationName: 'Near Besham, KKH',
              tempC: 24,
              condition: 'Partly Cloudy',
              roadStatus: 'Clear, minor debris ahead',
              isSafe: true,
            ),
            const SizedBox(height: 22),
            const Text('Quick Actions',
                style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textPrimary)),
            const SizedBox(height: 12),
            GridView.count(
              crossAxisCount: 4,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              children: [
                QuickActionButton(
                  icon: Icons.navigation_rounded,
                  label: 'Start Journey',
                  color: AppColors.darkBlue,
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => const LiveRouteScreen())),
                ),
                QuickActionButton(
                  icon: Icons.report_gmailerrorred_rounded,
                  label: 'Hotspots',
                  color: AppColors.danger,
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => const HotspotsScreen())),
                ),
                QuickActionButton(
                  icon: Icons.cloud_rounded,
                  label: 'Weather',
                  color: AppColors.info,
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => const WeatherScreen())),
                ),
                QuickActionButton(
                  icon: Icons.emergency_rounded,
                  label: 'Emergency',
                  color: AppColors.warning,
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => const EmergencyScreen())),
                ),
              ],
            ),
            const SizedBox(height: 22),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: AppColors.greenGradient,
                borderRadius: BorderRadius.circular(AppRadius.lg),
                boxShadow: AppShadows.soft,
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.auto_awesome_rounded,
                        color: Colors.white, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('AI Recommendation',
                            style: TextStyle(
                                color: Colors.white70,
                                fontSize: 11.5,
                                fontWeight: FontWeight.w700)),
                        const SizedBox(height: 4),
                        Text(
                          'Heavy rain expected after Besham. Drive carefully.',
                          style: TextStyle(
                              color: Colors.white.withOpacity(0.95),
                              fontSize: 13.5,
                              fontWeight: FontWeight.w600,
                              height: 1.3),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 22),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Recent Alerts',
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary)),
                TextButton(
                  onPressed: () {},
                  child: const Text('See all',
                      style: TextStyle(
                          color: AppColors.darkBlue,
                          fontWeight: FontWeight.w600,
                          fontSize: 12.5)),
                ),
              ],
            ),
            const SizedBox(height: 8),
            ...dummyLiveAlerts.take(2).map((a) => Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(AppRadius.md),
                    boxShadow: AppShadows.card,
                    border: Border(
                        left: BorderSide(color: a.risk.color, width: 4)),
                  ),
                  child: Row(
                    children: [
                      Icon(a.type.icon, color: a.risk.color, size: 22),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(a.type.title,
                                style: const TextStyle(
                                    fontWeight: FontWeight.w700, fontSize: 13.5)),
                            Text('${a.distanceKm.toStringAsFixed(1)} km ahead',
                                style: const TextStyle(
                                    color: AppColors.textSecondary,
                                    fontSize: 11.5)),
                          ],
                        ),
                      ),
                      RiskBadge(risk: a.risk),
                    ],
                  ),
                )),
          ],
        ),
      ),
    );
  }
}
