import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'settings_screen.dart';
import 'login_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: AppColors.primaryGradient,
                borderRadius: BorderRadius.circular(AppRadius.xl),
                boxShadow: AppShadows.soft,
              ),
              child: Column(
                children: [
                  Container(
                    width: 84,
                    height: 84,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.15),
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white38, width: 2),
                    ),
                    child: const Icon(Icons.person_rounded,
                        color: Colors.white, size: 44),
                  ),
                  const SizedBox(height: 14),
                  const Text('Ahmad Raza',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Text('Toyota Corolla · LEA-2026',
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.8), fontSize: 12.5)),
                ],
              ),
            ),
            const SizedBox(height: 20),
            _infoTile(Icons.directions_car_filled_rounded, 'Vehicle Info',
                'Toyota Corolla, White, 2022'),
            _infoTile(Icons.contact_phone_rounded, 'Emergency Contact',
                '+92 300 1234567 (Spouse)'),
            const SizedBox(height: 10),
            _menuTile(context, Icons.settings_rounded, 'Settings', () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const SettingsScreen()),
              );
            }),
            _menuTile(context, Icons.notifications_none_rounded,
                'Notifications', () {}),
            _menuTile(context, Icons.dark_mode_outlined, 'Dark Mode', () {}),
            _menuTile(context, Icons.help_outline_rounded, 'Help & Support',
                () {}),
            const SizedBox(height: 10),
            _menuTile(context, Icons.logout_rounded, 'Logout', () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginScreen()),
                (route) => false,
              );
            }, isDestructive: true),
          ],
        ),
      ),
    );
  }

  Widget _infoTile(IconData icon, String title, String subtitle) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppRadius.md),
        boxShadow: AppShadows.card,
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.darkBlue.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: AppColors.darkBlue, size: 20),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title,
                  style:
                      const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
              Text(subtitle,
                  style: const TextStyle(
                      fontSize: 12, color: AppColors.textSecondary)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _menuTile(BuildContext context, IconData icon, String label,
      VoidCallback onTap,
      {bool isDestructive = false}) {
    final color = isDestructive ? AppColors.danger : AppColors.textPrimary;
    return Material(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(AppRadius.md),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppRadius.md),
        onTap: onTap,
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppRadius.md),
            boxShadow: AppShadows.card,
          ),
          child: Row(
            children: [
              Icon(icon, color: color, size: 20),
              const SizedBox(width: 14),
              Expanded(
                child: Text(label,
                    style: TextStyle(
                        color: color,
                        fontWeight: FontWeight.w600,
                        fontSize: 13.5)),
              ),
              Icon(Icons.chevron_right_rounded,
                  color: AppColors.greyMedium.withOpacity(0.8)),
            ],
          ),
        ),
      ),
    );
  }
}
