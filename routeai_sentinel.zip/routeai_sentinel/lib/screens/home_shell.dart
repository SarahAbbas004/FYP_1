import 'package:flutter/material.dart';
import '../widgets/nav_and_buttons.dart';
import 'home_dashboard_screen.dart';
import 'live_route_screen.dart';
import 'live_alert_screen.dart';
import 'travel_history_screen.dart';
import 'profile_screen.dart';

/// App shell that owns the bottom navigation bar and swaps between the
/// five primary destinations: Home, Live Route, Alerts, History, Profile.
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  final _screens = const [
    HomeDashboardScreen(),
    LiveRouteScreen(),
    LiveAlertScreen(),
    TravelHistoryScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _index, children: _screens),
      bottomNavigationBar: AppBottomNav(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
      ),
    );
  }
}
