import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _notifications = true;
  bool _darkMode = false;
  String _language = 'English';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        children: [
          _sectionLabel('Preferences'),
          _switchTile(
            Icons.notifications_active_rounded,
            'Notifications',
            'Get alerted about hotspots and weather',
            _notifications,
            (v) => setState(() => _notifications = v),
          ),
          _switchTile(
            Icons.dark_mode_rounded,
            'Dark Mode',
            'Switch between light and dark theme',
            _darkMode,
            (v) => setState(() => _darkMode = v),
          ),
          _pickerTile(Icons.language_rounded, 'Language', _language, () {
            setState(() {
              _language = _language == 'English' ? 'Urdu' : 'English';
            });
          }),
          const SizedBox(height: 8),
          _sectionLabel('General'),
          _navTile(Icons.privacy_tip_rounded, 'Privacy', () {}),
          _navTile(Icons.help_outline_rounded, 'Help', () {}),
          _navTile(Icons.info_outline_rounded, 'About RouteAI Sentinel', () {}),
        ],
      ),
    );
  }

  Widget _sectionLabel(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 10, top: 6),
        child: Text(text,
            style: const TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w700,
                color: AppColors.textSecondary)),
      );

  Widget _switchTile(IconData icon, String title, String subtitle, bool value,
      ValueChanged<bool> onChanged) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppRadius.md),
        boxShadow: AppShadows.card,
      ),
      child: Row(
        children: [
          Icon(icon, color: AppColors.darkBlue, size: 20),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontWeight: FontWeight.w700, fontSize: 13.5)),
                Text(subtitle,
                    style: const TextStyle(
                        fontSize: 11.5, color: AppColors.textSecondary)),
              ],
            ),
          ),
          Switch(
              value: value,
              activeColor: AppColors.green,
              onChanged: onChanged),
        ],
      ),
    );
  }

  Widget _pickerTile(
      IconData icon, String title, String value, VoidCallback onTap) {
    return Material(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(AppRadius.md),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppRadius.md),
        onTap: onTap,
        child: Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppRadius.md),
            boxShadow: AppShadows.card,
          ),
          child: Row(
            children: [
              Icon(icon, color: AppColors.darkBlue, size: 20),
              const SizedBox(width: 14),
              Expanded(
                  child: Text(title,
                      style: const TextStyle(
                          fontWeight: FontWeight.w700, fontSize: 13.5))),
              Text(value,
                  style: const TextStyle(
                      fontSize: 12.5, color: AppColors.textSecondary)),
              const SizedBox(width: 4),
              const Icon(Icons.chevron_right_rounded,
                  color: AppColors.greyMedium),
            ],
          ),
        ),
      ),
    );
  }

  Widget _navTile(IconData icon, String title, VoidCallback onTap) {
    return Material(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(AppRadius.md),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppRadius.md),
        onTap: onTap,
        child: Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppRadius.md),
            boxShadow: AppShadows.card,
          ),
          child: Row(
            children: [
              Icon(icon, color: AppColors.darkBlue, size: 20),
              const SizedBox(width: 14),
              Expanded(
                  child: Text(title,
                      style: const TextStyle(
                          fontWeight: FontWeight.w600, fontSize: 13.5))),
              const Icon(Icons.chevron_right_rounded,
                  color: AppColors.greyMedium),
            ],
          ),
        ),
      ),
    );
  }
}
