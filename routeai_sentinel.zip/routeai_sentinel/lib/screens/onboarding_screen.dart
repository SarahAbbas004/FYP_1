import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import '../theme/app_theme.dart';
import '../widgets/gradient_button.dart';
import 'login_screen.dart';

class _OnboardData {
  final IconData icon;
  final String title;
  final String description;
  const _OnboardData(
      {required this.icon, required this.title, required this.description});
}

const _pages = [
  _OnboardData(
    icon: Icons.shield_rounded,
    title: 'Safe Travel with AI',
    description:
        'RouteAI Sentinel uses artificial intelligence to keep you informed '
        'and safe throughout your journey on the Karakoram Highway.',
  ),
  _OnboardData(
    icon: Icons.warning_amber_rounded,
    title: 'Historical Accident Detection',
    description:
        'Get notified before you reach locations with a history of accidents, '
        'so you can slow down and stay alert in advance.',
  ),
  _OnboardData(
    icon: Icons.cloud_queue_rounded,
    title: 'Weather Prediction & Driver Alerts',
    description:
        'Real-time weather forecasting along your route helps you decide '
        'whether it is safe to continue driving or better to stop and wait.',
  ),
];

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _controller = PageController();
  int _index = 0;

  void _goToLogin() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isLast = _index == _pages.length - 1;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: Alignment.topRight,
              child: Padding(
                padding: const EdgeInsets.only(right: 20, top: 8),
                child: TextButton(
                  onPressed: _goToLogin,
                  child: const Text('Skip',
                      style: TextStyle(
                          color: AppColors.textSecondary,
                          fontWeight: FontWeight.w600)),
                ),
              ),
            ),
            Expanded(
              child: PageView.builder(
                controller: _controller,
                itemCount: _pages.length,
                onPageChanged: (i) => setState(() => _index = i),
                itemBuilder: (context, i) {
                  final page = _pages[i];
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 32),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 220,
                          height: 220,
                          decoration: BoxDecoration(
                            gradient: AppColors.primaryGradient,
                            shape: BoxShape.circle,
                            boxShadow: AppShadows.soft,
                          ),
                          child: Icon(page.icon,
                              color: Colors.white, size: 90),
                        ),
                        const SizedBox(height: 40),
                        Text(
                          page.title,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.w800,
                              color: AppColors.textPrimary),
                        ),
                        const SizedBox(height: 14),
                        Text(
                          page.description,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              fontSize: 14.5,
                              height: 1.5,
                              color: AppColors.textSecondary),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            SmoothPageIndicator(
              controller: _controller,
              count: _pages.length,
              effect: const ExpandingDotsEffect(
                activeDotColor: AppColors.darkBlue,
                dotColor: AppColors.greyLight,
                dotHeight: 8,
                dotWidth: 8,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(24),
              child: Row(
                children: [
                  if (!isLast)
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () {
                          _controller.nextPage(
                            duration: const Duration(milliseconds: 350),
                            curve: Curves.easeOut,
                          );
                        },
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          side: const BorderSide(color: AppColors.darkBlue),
                          shape: RoundedRectangleBorder(
                              borderRadius:
                                  BorderRadius.circular(AppRadius.md)),
                        ),
                        child: const Text('Next',
                            style: TextStyle(
                                color: AppColors.darkBlue,
                                fontWeight: FontWeight.w700)),
                      ),
                    ),
                  if (isLast)
                    Expanded(
                      child: GradientButton(
                        label: 'Get Started',
                        gradient: AppColors.greenGradient,
                        icon: Icons.arrow_forward_rounded,
                        onPressed: _goToLogin,
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
