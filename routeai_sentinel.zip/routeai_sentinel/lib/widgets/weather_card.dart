import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/app_models.dart';

/// Large hero-style weather card used on the Home Dashboard.
class WeatherHeroCard extends StatelessWidget {
  final String locationName;
  final int tempC;
  final String condition;
  final String roadStatus;
  final bool isSafe;

  const WeatherHeroCard({
    super.key,
    required this.locationName,
    required this.tempC,
    required this.condition,
    required this.roadStatus,
    required this.isSafe,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppColors.skyGradient,
        borderRadius: BorderRadius.circular(AppRadius.xl),
        boxShadow: AppShadows.soft,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const Icon(Icons.location_on_rounded,
                      color: Colors.white70, size: 18),
                  const SizedBox(width: 4),
                  Text(locationName,
                      style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 13,
                          fontWeight: FontWeight.w600)),
                ],
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: isSafe
                      ? AppColors.safe.withOpacity(0.9)
                      : AppColors.warning.withOpacity(0.9),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    Icon(
                        isSafe
                            ? Icons.check_circle_rounded
                            : Icons.error_rounded,
                        color: Colors.white,
                        size: 14),
                    const SizedBox(width: 4),
                    Text(
                      isSafe ? 'Safe to Travel' : 'Use Caution',
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '$tempC°',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 56,
                  fontWeight: FontWeight.w300,
                  height: 1,
                ),
              ),
              const Padding(
                padding: EdgeInsets.only(top: 8),
                child: Icon(Icons.wb_cloudy_rounded,
                    color: Colors.white, size: 36),
              ),
            ],
          ),
          Text(condition,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w600)),
          const SizedBox(height: 16),
          Row(
            children: [
              Icon(Icons.route_rounded,
                  color: Colors.white.withOpacity(0.85), size: 16),
              const SizedBox(width: 6),
              Text(
                'Road Condition: $roadStatus',
                style: TextStyle(
                    color: Colors.white.withOpacity(0.9),
                    fontSize: 13,
                    fontWeight: FontWeight.w500),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// Compact forecast tile used in horizontal lists (hourly / 3-day).
class WeatherForecastTile extends StatelessWidget {
  final WeatherPoint point;

  const WeatherForecastTile({super.key, required this.point});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 96,
      margin: const EdgeInsets.only(right: 12),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppRadius.md),
        boxShadow: AppShadows.card,
      ),
      child: Column(
        children: [
          Text(point.label,
              style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textSecondary)),
          const SizedBox(height: 10),
          Icon(point.icon, color: AppColors.darkBlue, size: 28),
          const SizedBox(height: 10),
          Text('${point.tempC}°C',
              style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary)),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.water_drop_rounded,
                  size: 11, color: AppColors.info),
              const SizedBox(width: 2),
              Text('${point.rainChance}%',
                  style: const TextStyle(
                      fontSize: 11, color: AppColors.textSecondary)),
            ],
          ),
        ],
      ),
    );
  }
}
