import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// All models below are simple plain-Dart classes used only to hold
/// DUMMY / SAMPLE data for the frontend. No networking, persistence,
/// or AI logic is implemented — replace the `dummy*` lists with real
/// API-backed data when the backend is ready.

enum RiskLevel { red, orange, yellow }

extension RiskLevelX on RiskLevel {
  Color get color {
    switch (this) {
      case RiskLevel.red:
        return AppColors.danger;
      case RiskLevel.orange:
        return AppColors.warning;
      case RiskLevel.yellow:
        return const Color(0xFFE0C341);
    }
  }

  String get label {
    switch (this) {
      case RiskLevel.red:
        return 'High Risk';
      case RiskLevel.orange:
        return 'Moderate Risk';
      case RiskLevel.yellow:
        return 'Low Risk';
    }
  }
}

class AccidentHotspot {
  final String location;
  final RiskLevel risk;
  final int pastAccidents;
  final String reason;
  final String date;
  final double progressAlongRoute; // 0..1 for map placement

  const AccidentHotspot({
    required this.location,
    required this.risk,
    required this.pastAccidents,
    required this.reason,
    required this.date,
    required this.progressAlongRoute,
  });
}

final List<AccidentHotspot> dummyHotspots = [
  const AccidentHotspot(
    location: 'Thakot Bridge Curve',
    risk: RiskLevel.red,
    pastAccidents: 14,
    reason: 'Sharp blind curve with loose gravel',
    date: 'Reported: 12 Mar 2026',
    progressAlongRoute: 0.22,
  ),
  const AccidentHotspot(
    location: 'Besham Bypass',
    risk: RiskLevel.orange,
    pastAccidents: 9,
    reason: 'Frequent landslide debris on road',
    date: 'Reported: 02 Apr 2026',
    progressAlongRoute: 0.35,
  ),
  const AccidentHotspot(
    location: 'Dasu Tunnel Exit',
    risk: RiskLevel.yellow,
    pastAccidents: 4,
    reason: 'Poor lighting at tunnel exit',
    date: 'Reported: 18 May 2026',
    progressAlongRoute: 0.52,
  ),
  const AccidentHotspot(
    location: 'Chilas Flood Zone',
    risk: RiskLevel.red,
    pastAccidents: 17,
    reason: 'Seasonal flash flooding across road',
    date: 'Reported: 30 Jun 2026',
    progressAlongRoute: 0.71,
  ),
  const AccidentHotspot(
    location: 'Jaglot Junction',
    risk: RiskLevel.orange,
    pastAccidents: 7,
    reason: 'Heavy truck congestion, narrow lanes',
    date: 'Reported: 09 Jul 2026',
    progressAlongRoute: 0.86,
  ),
];

class WeatherPoint {
  final String label; // e.g. "Now", "3 PM", "Tomorrow"
  final IconData icon;
  final int tempC;
  final int rainChance;
  final String condition;

  const WeatherPoint({
    required this.label,
    required this.icon,
    required this.tempC,
    required this.rainChance,
    required this.condition,
  });
}

final List<WeatherPoint> dummyHourlyWeather = [
  const WeatherPoint(
      label: 'Now',
      icon: Icons.wb_sunny_rounded,
      tempC: 27,
      rainChance: 5,
      condition: 'Clear'),
  const WeatherPoint(
      label: '1 PM',
      icon: Icons.wb_cloudy_rounded,
      tempC: 26,
      rainChance: 15,
      condition: 'Partly Cloudy'),
  const WeatherPoint(
      label: '4 PM',
      icon: Icons.cloud_rounded,
      tempC: 23,
      rainChance: 40,
      condition: 'Cloudy'),
  const WeatherPoint(
      label: '7 PM',
      icon: Icons.grain_rounded,
      tempC: 19,
      rainChance: 70,
      condition: 'Light Rain'),
  const WeatherPoint(
      label: '10 PM',
      icon: Icons.thunderstorm_rounded,
      tempC: 17,
      rainChance: 82,
      condition: 'Heavy Rain'),
];

final List<WeatherPoint> dummyThreeDayWeather = [
  const WeatherPoint(
      label: 'Today',
      icon: Icons.wb_sunny_rounded,
      tempC: 27,
      rainChance: 10,
      condition: 'Clear Skies'),
  const WeatherPoint(
      label: 'Tomorrow',
      icon: Icons.grain_rounded,
      tempC: 21,
      rainChance: 65,
      condition: 'Rain expected after Besham'),
  const WeatherPoint(
      label: 'Day 3',
      icon: Icons.cloud_rounded,
      tempC: 19,
      rainChance: 45,
      condition: 'Overcast, cooler near Gilgit'),
];

enum AlertType { landslide, rain, accidentZone, roadClosed, driveSlow }

extension AlertTypeX on AlertType {
  IconData get icon {
    switch (this) {
      case AlertType.landslide:
        return Icons.terrain_rounded;
      case AlertType.rain:
        return Icons.water_drop_rounded;
      case AlertType.accidentZone:
        return Icons.warning_amber_rounded;
      case AlertType.roadClosed:
        return Icons.block_rounded;
      case AlertType.driveSlow:
        return Icons.speed_rounded;
    }
  }

  String get title {
    switch (this) {
      case AlertType.landslide:
        return 'Landslide Ahead';
      case AlertType.rain:
        return 'Heavy Rain Ahead';
      case AlertType.accidentZone:
        return 'Accident Prone Area';
      case AlertType.roadClosed:
        return 'Road Closed';
      case AlertType.driveSlow:
        return 'Drive Slowly';
    }
  }
}

class LiveAlert {
  final AlertType type;
  final String description;
  final double distanceKm;
  final String recommendedAction;
  final RiskLevel risk;

  const LiveAlert({
    required this.type,
    required this.description,
    required this.distanceKm,
    required this.recommendedAction,
    required this.risk,
  });
}

final List<LiveAlert> dummyLiveAlerts = [
  const LiveAlert(
    type: AlertType.landslide,
    description: 'Debris reported on the carriageway near Komila.',
    distanceKm: 4.2,
    recommendedAction: 'Reduce speed and maintain distance from the cliffside.',
    risk: RiskLevel.red,
  ),
  const LiveAlert(
    type: AlertType.rain,
    description: 'Heavy rainfall expected within the next 30 minutes.',
    distanceKm: 12.8,
    recommendedAction: 'Turn on headlights and reduce speed.',
    risk: RiskLevel.orange,
  ),
  const LiveAlert(
    type: AlertType.accidentZone,
    description: 'Historically high accident frequency in this stretch.',
    distanceKm: 22.5,
    recommendedAction: 'Stay alert, avoid overtaking on curves.',
    risk: RiskLevel.orange,
  ),
  const LiveAlert(
    type: AlertType.driveSlow,
    description: 'Narrow lane with oncoming truck traffic.',
    distanceKm: 1.1,
    recommendedAction: 'Reduce speed to under 30 km/h.',
    risk: RiskLevel.yellow,
  ),
];

class Journey {
  final String date;
  final String start;
  final String destination;
  final String weather;
  final String duration;
  final String roadStatus;

  const Journey({
    required this.date,
    required this.start,
    required this.destination,
    required this.weather,
    required this.duration,
    required this.roadStatus,
  });
}

final List<Journey> dummyJourneys = [
  const Journey(
    date: '14 Jul 2026',
    start: 'Islamabad',
    destination: 'Gilgit',
    weather: 'Clear, 26°C',
    duration: '11h 20m',
    roadStatus: 'Safe',
  ),
  const Journey(
    date: '02 Jun 2026',
    start: 'Gilgit',
    destination: 'Islamabad',
    weather: 'Light Rain',
    duration: '12h 05m',
    roadStatus: 'Caution',
  ),
  const Journey(
    date: '19 Apr 2026',
    start: 'Islamabad',
    destination: 'Chilas',
    weather: 'Clear, 24°C',
    duration: '7h 40m',
    roadStatus: 'Safe',
  ),
];
